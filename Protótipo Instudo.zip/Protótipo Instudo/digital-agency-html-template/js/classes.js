class Usuario{
    constructor(nome, sobrenome, nomeUser, cidade, estado, foto, email, senha, convenio){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.nomeUser = nomeUser;
        this.cidade = cidade;
        this.estado = estado;
        this.foto = foto;
        this.email = email;
        this.senha = senha;
        this.convenio = convenio
    }
}

